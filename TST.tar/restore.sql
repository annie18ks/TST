--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SJIS';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.message DROP CONSTRAINT message_number_fkey;
ALTER TABLE ONLY public.message DROP CONSTRAINT message_pkey;
ALTER TABLE ONLY public.malice DROP CONSTRAINT malice_pkey;
ALTER TABLE ONLY public.malice DROP CONSTRAINT malice_accountid_key;
ALTER TABLE ONLY public.general DROP CONSTRAINT general_pkey;
ALTER TABLE ONLY public.general DROP CONSTRAINT general_accountid_key;
ALTER TABLE public.message ALTER COLUMN messageid DROP DEFAULT;
ALTER TABLE public.malice ALTER COLUMN number DROP DEFAULT;
ALTER TABLE public.general ALTER COLUMN number DROP DEFAULT;
DROP SEQUENCE public.message_messageid_seq;
DROP TABLE public.message;
DROP SEQUENCE public.malice_number_seq;
DROP TABLE public.malice;
DROP SEQUENCE public.general_number_seq;
DROP TABLE public.general;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: general; Type: TABLE; Schema: public; Owner: tstuser
--

CREATE TABLE general (
    number integer NOT NULL,
    accountid text NOT NULL,
    password text NOT NULL,
    publickey bytea,
    privatekey bytea
);


ALTER TABLE general OWNER TO tstuser;

--
-- Name: general_number_seq; Type: SEQUENCE; Schema: public; Owner: tstuser
--

CREATE SEQUENCE general_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE general_number_seq OWNER TO tstuser;

--
-- Name: general_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tstuser
--

ALTER SEQUENCE general_number_seq OWNED BY general.number;


--
-- Name: malice; Type: TABLE; Schema: public; Owner: tstuser
--

CREATE TABLE malice (
    number integer NOT NULL,
    accountid text NOT NULL,
    password text NOT NULL
);


ALTER TABLE malice OWNER TO tstuser;

--
-- Name: malice_number_seq; Type: SEQUENCE; Schema: public; Owner: tstuser
--

CREATE SEQUENCE malice_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE malice_number_seq OWNER TO tstuser;

--
-- Name: malice_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tstuser
--

ALTER SEQUENCE malice_number_seq OWNED BY malice.number;


--
-- Name: message; Type: TABLE; Schema: public; Owner: tstuser
--

CREATE TABLE message (
    messageid integer NOT NULL,
    message text,
    tst bytea,
    number integer
);


ALTER TABLE message OWNER TO tstuser;

--
-- Name: message_messageid_seq; Type: SEQUENCE; Schema: public; Owner: tstuser
--

CREATE SEQUENCE message_messageid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE message_messageid_seq OWNER TO tstuser;

--
-- Name: message_messageid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tstuser
--

ALTER SEQUENCE message_messageid_seq OWNED BY message.messageid;


--
-- Name: general number; Type: DEFAULT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY general ALTER COLUMN number SET DEFAULT nextval('general_number_seq'::regclass);


--
-- Name: malice number; Type: DEFAULT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY malice ALTER COLUMN number SET DEFAULT nextval('malice_number_seq'::regclass);


--
-- Name: message messageid; Type: DEFAULT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY message ALTER COLUMN messageid SET DEFAULT nextval('message_messageid_seq'::regclass);


--
-- Data for Name: general; Type: TABLE DATA; Schema: public; Owner: tstuser
--

COPY general (number, accountid, password, publickey, privatekey) FROM stdin;
\.
COPY general (number, accountid, password, publickey, privatekey) FROM '$$PATH$$/2147.dat';

--
-- Name: general_number_seq; Type: SEQUENCE SET; Schema: public; Owner: tstuser
--

SELECT pg_catalog.setval('general_number_seq', 1, false);


--
-- Data for Name: malice; Type: TABLE DATA; Schema: public; Owner: tstuser
--

COPY malice (number, accountid, password) FROM stdin;
\.
COPY malice (number, accountid, password) FROM '$$PATH$$/2149.dat';

--
-- Name: malice_number_seq; Type: SEQUENCE SET; Schema: public; Owner: tstuser
--

SELECT pg_catalog.setval('malice_number_seq', 1, false);


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: tstuser
--

COPY message (messageid, message, tst, number) FROM stdin;
\.
COPY message (messageid, message, tst, number) FROM '$$PATH$$/2151.dat';

--
-- Name: message_messageid_seq; Type: SEQUENCE SET; Schema: public; Owner: tstuser
--

SELECT pg_catalog.setval('message_messageid_seq', 1, false);


--
-- Name: general general_accountid_key; Type: CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY general
    ADD CONSTRAINT general_accountid_key UNIQUE (accountid);


--
-- Name: general general_pkey; Type: CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY general
    ADD CONSTRAINT general_pkey PRIMARY KEY (number);


--
-- Name: malice malice_accountid_key; Type: CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY malice
    ADD CONSTRAINT malice_accountid_key UNIQUE (accountid);


--
-- Name: malice malice_pkey; Type: CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY malice
    ADD CONSTRAINT malice_pkey PRIMARY KEY (number);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY message
    ADD CONSTRAINT message_pkey PRIMARY KEY (messageid);


--
-- Name: message message_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tstuser
--

ALTER TABLE ONLY message
    ADD CONSTRAINT message_number_fkey FOREIGN KEY (number) REFERENCES general(number);


--
-- PostgreSQL database dump complete
--

